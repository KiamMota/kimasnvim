vim.keymap.set('n', '<C-s>', '<cmd>write<CR>', { noremap = true, silent = true })
vim.keymap.set('i', '<C-s>', '<Esc><cmd>write<CR>a', { noremap = true, silent = true })
vim.keymap.set('v', '<C-s>', '<Esc><cmd>write<CR>gv', { noremap = true, silent = true })

vim.keymap.set('n', '<leader>rr', function()
  local file          = vim.fn.expand('%:t:r') -- nome do arquivo atual sem extensão
  local mod           = vim.fn.expand('%:.:r') -- caminho relativo sem extensão
      :gsub('/', '.')                 -- converte / para .
      :gsub('lua%.', '')              -- remove prefixo lua.
  package.loaded[mod] = nil
  require(mod)
  vim.notify('Reloaded: ' .. mod)
end, { desc = 'Reload current lua file' })
vim.keymap.set('n', '<C-a>', function()
  vim.cmd('normal! ggVG')
end)

vim.keymap.set('n', '<Up>', '<Nop>')
vim.keymap.set('n', '<Down>', '<Nop>')
vim.keymap.set('n', '<Left>', '<Nop>')
vim.keymap.set('n', '<Right>', '<Nop>')



vim.keymap.set('i', '<Up>', '<Nop>')
vim.keymap.set('i', '<Down>', '<Nop>')
vim.keymap.set('i', '<Left>', '<Nop>')
vim.keymap.set('i', '<Right>', '<Nop>')

vim.keymap.set('n', '<C-Left>', ':bprevious<CR>', { desc = 'prev buf' })
vim.keymap.set('n', '<C-Right>', ':bnext<CR>', { desc = 'next buf' })

vim.keymap.set('n', '<C-l>', ":bnext<CR>")
vim.keymap.set('n', '<C-h>', ":bnext<CR>")

vim.keymap.set('n', '<A-h>', '<C-w>h')
vim.keymap.set('n', '<A-j>', '<C-w>j')
vim.keymap.set('n', '<A-k>', '<C-w>k')
vim.keymap.set('n', '<A-l>', '<C-w>l')

vim.keymap.set('n', '<S-Tab>', ':bnext<CR>')

vim.cmd([[cnoreabbrev Thisd lcd %:p:h]])
vim.keymap.set('n', '<C-b>', ':bdelete<CR>', { silent = true })
vim.keymap.set("n", "<A-j>", function()
  vim.cmd("m .+1")
  vim.cmd("normal! ==")
end, { silent = true })

vim.keymap.set("n", "<A-k>", function()
  vim.cmd("m .-2")
  vim.cmd("normal! ==")
end, { silent = true })
